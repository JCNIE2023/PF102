 // Profile Picture Upload
document.getElementById("imageUpload").addEventListener("change", function(event) {
    let file = event.target.files[0];
    let reader = new FileReader();

    reader.onload = function(e) {
        let preview = document.getElementById("preview");
        preview.src = e.target.result;
        preview.style.display = "block";
    };

    reader.readAsDataURL(file);
});

// Save Profile Data and Redirect
document.getElementById("profileForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Save data to localStorage
    localStorage.setItem("name", document.getElementById("name").value);
    localStorage.setItem("birthday", document.getElementById("birthday").value);
    localStorage.setItem("bio", document.getElementById("bio").value);
    localStorage.setItem("quote", document.getElementById("quote").value);
    localStorage.setItem("profileImage", document.getElementById("preview").src);

    // Redirect to feed page
    window.location.href = "feed.html";
});