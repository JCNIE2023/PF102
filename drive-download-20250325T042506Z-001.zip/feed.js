// Define the audio element
const audio = new Audio();
audio.src = "click-.mp3"; // Make sure this path is correct and the file exists

// Load Profile Data in Feed Page
window.onload = function() {
    document.getElementById("displayName").textContent = localStorage.getItem("name");
    document.getElementById("displayBirthday").textContent = localStorage.getItem("birthday");
    document.getElementById("displayBio").textContent = localStorage.getItem("bio");
    document.getElementById("displayQuote").textContent = localStorage.getItem("quote");
    document.getElementById("profileImage").src = localStorage.getItem("profileImage");
};

// Tweet Posting
document.getElementById("postTweet").addEventListener("click", function() {
    let tweetInput = document.getElementById("tweetInput");
    let tweetText = tweetInput.value.trim();

    if (tweetText) {
        let tweetFeed = document.getElementById("tweetFeed");
        let tweetDiv = document.createElement("div");
        tweetDiv.classList.add("tweet");

        tweetDiv.innerHTML = `
            <p>${tweetText}</p>
            <span class='heart' onclick='toggleLike(this)'>♡</span>
            <button onclick='removeTweet(this)'>Delete</button>
        `;

        tweetFeed.appendChild(tweetDiv);
        tweetInput.value = ""; // Clear input after posting
    }
});

// Like Tweet Function (toggle like/unlike)
function toggleLike(heart) {
    // Toggle the heart symbol between liked and unliked
    heart.textContent = heart.textContent === "♡" ? "♥" : "♡";

    // Play the sound when like/unlike happens
    audio.play();
}

// Remove Tweet Function
function removeTweet(button) {
    button.parentElement.remove();
}
